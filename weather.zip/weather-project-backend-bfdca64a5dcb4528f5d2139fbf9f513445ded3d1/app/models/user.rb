class User < ApplicationRecord

    has_many :favorites

end
